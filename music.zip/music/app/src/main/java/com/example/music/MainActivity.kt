package com.example.music

import android.content.ContentValues.TAG
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.music.databinding.ActivityMainBinding
import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val mediaPlayer = MediaPlayer()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityMainBinding.inflate(layoutInflater)
        var view=binding.root
        setContentView(view)
        initMediaPlayer()
        binding.play.setOnClickListener {
            if (!mediaPlayer.isPlaying) {
                    mediaPlayer.start() // 开始播放
            }
        }
        binding.pause.setOnClickListener {
            if (mediaPlayer.isPlaying) {
                mediaPlayer.pause() // 暂停播放
            }
        }
        binding.stop.setOnClickListener {
            if (mediaPlayer.isPlaying) {
                mediaPlayer.reset() // 停止播放
                initMediaPlayer()
            }
        }
    }
    private fun initMediaPlayer() {
        //val assetManager = assets
        mediaPlayer.setAudioAttributes(
            AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
        )
        val mysongurl="https://m701.music.126.net/20220425193400/276a33076291c93be0d6afd014bd8b3e/jdyyaac/5408/0e59/5552/cb6440bbec939dee158eb89e8511146c.m4a"
        try {
            mediaPlayer.setDataSource(mysongurl)
            mediaPlayer.prepare()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        Log.v(TAG,"Music is streaming")
//        var urlx="http://localhost:3000/search?keywords="
//        var keyword="后来"
//        urlx+=keyword
//        val url= URL(urlx)
//        val connection = url.openConnection() as HttpURLConnection
//        connection.requestMethod = "GET"
//        val input = connection.inputStream
//        connection.disconnect()
        //val jsonObject = jsonArray.getJSONObject(0)
        //val result = jsonObjectResult.


    }
    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer.stop()
        mediaPlayer.release()
    }

}